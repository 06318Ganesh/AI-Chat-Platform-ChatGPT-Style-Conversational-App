// backend/server.js
// Simple in-memory backend for chat (no DB).
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const crypto = require("crypto");
const fetch = require("node-fetch"); // only used if GEMINI_API_KEY set (optional)

const app = express();
app.use(cors());
app.use(bodyParser.json());

/* In-memory store */
const sessions = {}; // { sessionId: { id, title, createdAt, messages: [{id,role,text,createdAt}] } }

const now = () => Date.now();
const makeId = (prefix = "") => `${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;

const generateTitle = (seed) => {
  const n = Object.keys(sessions).length + 1;
  if (seed && seed.trim()) return `Chat ${n} — ${seed.slice(0, 30)}`;
  return `Chat ${n}`;
};

// Optional helper for AI calls (illustrative only)
async function tryGemini(query) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  try {
    // NOTE: This is illustrative. Replace endpoint/payload for your actual Gemini usage.
    const prompt = `Return a JSON object with keys title, description, columns (array), rows (array of objects), summary for: "${query}"`;
    const resp = await fetch("https://api.labs.google.com/v1alpha/models/gemini-pro:generateText", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ prompt, maxOutputTokens: 512 })
    });
    const json = await resp.json();
    const raw = json?.candidates?.[0]?.content || JSON.stringify(json);
    try {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.columns && parsed.rows) {
        return { text: parsed.summary || raw, table: parsed };
      }
    } catch (e) {
      // not JSON, fallback to text
      return { text: raw, table: null };
    }
  } catch (err) {
    console.error("Gemini error:", err);
    return null;
  }
}

// Create new session
app.post("/api/sessions/new", (req, res) => {
  const titleSeed = req.body?.title || "";
  const sid = makeId("s");
  sessions[sid] = { id: sid, title: generateTitle(titleSeed), createdAt: now(), messages: [] };
  res.json({ sessionId: sid, title: sessions[sid].title });
});

// List sessions
app.get("/api/sessions", (req, res) => {
  const list = Object.values(sessions).map((s) => {
    const lastMsg = s.messages.length ? s.messages[s.messages.length - 1] : null;
    const lastActivity = lastMsg ? lastMsg.createdAt : s.createdAt;
    return { id: s.id, title: s.title, lastMessage: lastMsg ? lastMsg.text : "", lastActivity };
  }).sort((a, b) => b.lastActivity - a.lastActivity);
  res.json(list);
});

// Get session history
app.get("/api/sessions/:id", (req, res) => {
  const s = sessions[req.params.id];
  if (!s) return res.status(404).json({ error: "Session not found" });
  res.json(s);
});

// Rename session
app.post("/api/sessions/:id/rename", (req, res) => {
  const s = sessions[req.params.id];
  if (!s) return res.status(404).json({ error: "Session not found" });
  const title = req.body?.title;
  if (title && title.trim()) s.title = title;
  res.json({ ok: true, title: s.title });
});

// Delete session
app.delete("/api/sessions/:id", (req, res) => {
  const id = req.params.id;
  if (!sessions[id]) return res.status(404).json({ error: "Session not found" });
  delete sessions[id];
  res.json({ ok: true });
});

// Ask in session (saves user message, returns assistant reply + structured table)
app.post("/api/sessions/:id/ask", async (req, res) => {
  const sid = req.params.id;
  const q = String(req.body?.query || "");
  const s = sessions[sid];
  if (!s) return res.status(404).json({ error: "Session not found" });

  // Save user message
  const userMsg = { id: makeId("m"), role: "user", text: q, createdAt: now() };
  s.messages.push(userMsg);

  // Try Gemini if configured
  let assistantResult = null;
  if (process.env.GEMINI_API_KEY) {
    assistantResult = await tryGemini(q);
  }

  // Fallback dummy structured table
  if (!assistantResult) {
    const table = {
      title: `Sales Report for "${q || "sample"}"`,
      description: `Dummy structured data generated for query: "${q || "sample"}".`,
      columns: ["Product", "Units Sold", "Revenue", "Region"],
      rows: [
        { Product: "Widget A", "Units Sold": 120, "Revenue": "$1,800", Region: "North" },
        { Product: "Widget B", "Units Sold": 85, "Revenue": "$1,275", Region: "East" },
        { Product: "Widget C", "Units Sold": 200, "Revenue": "$4,000", Region: "West" }
      ],
      summary: `Found 3 products for "${q}".`
    };
    assistantResult = { text: table.summary, table };
  }

  // Save assistant message
  const assistantMsg = { id: makeId("m"), role: "assistant", text: assistantResult.text || "", createdAt: now() };
  s.messages.push(assistantMsg);

  res.json({ reply: assistantResult.text, table: assistantResult.table || null, assistantMessageId: assistantMsg.id });
});

// Feedback endpoint (like/dislike) - logs only
app.post("/api/messages/:id/feedback", (req, res) => {
  console.log("Feedback:", req.params.id, req.body?.feedback);
  res.json({ ok: true });
});

// Health
app.get("/api/health", (req, res) => {
  res.json({ ok: true, sessions: Object.keys(sessions).length });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
