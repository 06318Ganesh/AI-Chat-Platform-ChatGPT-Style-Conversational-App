export const API_BASE = "https://chat-application-project-xgwq.onrender.com";
