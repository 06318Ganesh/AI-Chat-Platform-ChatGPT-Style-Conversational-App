import React, { useState } from "react";

export default function Sidebar({
  collapsed,
  setCollapsed,
  sessions = [],
  activeSessionId,
  createNewSession,
  onSelect,
  renameSession,
  deleteSession
}) {
  const [editingId, setEditingId] = useState(null);
  const [titleInput, setTitleInput] = useState("");

  const startEdit = (s) => {
    setEditingId(s.id);
    setTitleInput(s.title);
  };

  const saveEdit = async (id) => {
    await renameSession(id, titleInput);
    setEditingId(null);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="text-xl font-bold">GPT</div>
          {!collapsed && <div className="text-sm text-gray-500">Conversations</div>}
        </div>
        <button onClick={() => setCollapsed(c => !c)} className="p-2 rounded hover:bg-gray-100">
          {collapsed ? "➤" : "◀"}
        </button>
      </div>

      <div className="p-3">
        {!collapsed ? (
          <button onClick={() => createNewSession()} className="w-full bg-green-600 text-white py-2 rounded-lg">+ New Chat</button>
        ) : (
          <button onClick={() => createNewSession()} className="w-full bg-green-600 text-white py-2 rounded-lg">+</button>
        )}
      </div>

      <div className="px-2 py-3 flex-1 overflow-auto">
        <div className="space-y-2">
          {sessions.map((s) => {
            const selected = activeSessionId === s.id;
            return (
              <div key={s.id} className={`p-2 rounded cursor-pointer flex items-center justify-between ${selected ? "bg-gray-200" : "hover:bg-gray-100"}`}>
                <div onClick={() => onSelect(s.id)} className="flex-1">
                  {!collapsed ? (
                    <>
                      <div className="text-sm font-medium">{s.title}</div>
                      <div className="text-xs text-gray-500">{s.lastMessage || s.id}</div>
                    </>
                  ) : (<div className="text-sm">{s.title.slice(0,2)}</div>)}
                </div>
                {!collapsed && (
                  <div className="flex items-center gap-2">
                    <button onClick={() => startEdit(s)} className="text-xs px-2 py-1 rounded hover:bg-gray-100">Rename</button>
                    <button onClick={() => deleteSession(s.id)} className="text-xs px-2 py-1 rounded hover:bg-gray-100">Delete</button>
                  </div>
                )}
                {editingId === s.id && (
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="bg-white p-3 rounded shadow">
                      <input value={titleInput} onChange={(e) => setTitleInput(e.target.value)} className="border px-2 py-1 mb-2" />
                      <div className="flex gap-2 justify-end">
                        <button onClick={() => saveEdit(s.id)} className="bg-blue-600 text-white px-3 py-1 rounded">Save</button>
                        <button onClick={() => setEditingId(null)} className="px-3 py-1 rounded">Cancel</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="p-3 border-t">
        <div className="flex items-center gap-3">
          <img src="https://cdn-icons-png.flaticon.com/512/1144/1144760.png" alt="user" className="w-10 h-10 rounded-full" />
          {!collapsed && (
            <div>
              <div className="text-sm font-medium">You</div>
              <div className="text-xs text-gray-500">ganes@example.com</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
