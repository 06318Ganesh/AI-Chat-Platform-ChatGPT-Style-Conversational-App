import React, { useEffect, useRef, useState } from "react";

export default function ChatWindow({ session, refresh, createNewSession, theme }) {
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [tableData, setTableData] = useState(null);
  const [feedback, setFeedback] = useState({});
  const endRef = useRef(null);

  const messages = session?.messages || [];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, isTyping, tableData]);

  const handleSend = async () => {
    if (!input.trim()) return;
    if (!session?.id) {
      await createNewSession();
      return;
    }
    const q = input.trim();
    setInput("");
    setIsTyping(true);
    setTableData(null);
    try {
      const res = await fetch(`http://localhost:5000/api/sessions/${session.id}/ask`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: q })
      });
      const data = await res.json();
      if (refresh) await refresh();
      setTableData(data.table || null);
      setIsTyping(false);
    } catch {
      if (refresh) await refresh();
      setIsTyping(false);
    }
  };

  const giveFeedback = async (msgId, type) => {
    setFeedback((p) => ({ ...p, [msgId]: type }));
    try {
      await fetch(`http://localhost:5000/api/messages/${msgId}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ feedback: type })
      });
    } catch (e) { /* ignore */ }
  };

  return (
    <div className={`flex flex-col h-full ${theme === "dark" ? "bg-gray-900 text-gray-100" : ""}`}>
      <div className={`p-4 border-b ${theme === "dark" ? "bg-gray-800" : "bg-white"}`}>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-semibold">{session?.title || "New Chat"}</div>
            <div className="text-xs text-gray-500">{session?.id || ""}</div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={`flex items-start gap-3 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            {m.role === "assistant" && <img src="https://cdn-icons-png.flaticon.com/512/4712/4712100.png" alt="bot" className="w-9 h-9 rounded-full" />}
            <div className={`max-w-[70%] p-3 rounded-2xl ${m.role === "user" ? "bg-blue-600 text-white" : "bg-white border"}`}>
              {m.text}
              {m.role === "assistant" && (
                <div className="mt-2 flex gap-2 text-xs">
                  <button onClick={() => giveFeedback(m.id, "like")} className={`px-2 py-1 rounded ${feedback[m.id] === "like" ? "bg-green-200" : "bg-gray-100"}`}>👍 Like</button>
                  <button onClick={() => giveFeedback(m.id, "dislike")} className={`px-2 py-1 rounded ${feedback[m.id] === "dislike" ? "bg-red-200" : "bg-gray-100"}`}>👎 Dislike</button>
                </div>
              )}
            </div>
            {m.role === "user" && <img src="https://cdn-icons-png.flaticon.com/512/1144/1144760.png" alt="you" className="w-9 h-9 rounded-full" />}
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-3">
            <img src="https://cdn-icons-png.flaticon.com/512/4712/4712100.png" alt="bot" className="w-9 h-9 rounded-full" />
            <div className="p-3 bg-white rounded-2xl border">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-150"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-300"></div>
              </div>
            </div>
          </div>
        )}

        <div ref={endRef}></div>

        {tableData && (
          <div className="mt-6 bg-white p-4 rounded shadow">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{tableData.title}</h3>
                <p className="text-sm text-gray-500">{tableData.description}</p>
              </div>
              <div className="text-xs text-gray-400">Structured Table</div>
            </div>

            <div className="overflow-auto mt-3">
              <table className="min-w-full text-sm">
                <thead>
                  <tr>
                    {tableData.columns.map((c) => <th key={c} className="px-3 py-2 bg-gray-100">{c}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {tableData.rows.map((row, i) => (
                    <tr key={i} className={i % 2 ? "bg-gray-50" : ""}>
                      {tableData.columns.map((col) => <td key={col} className="px-3 py-2 border">{row[col]}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t bg-white">
        <div className="flex gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleSend()} placeholder={session ? "Ask a question..." : "Click New Chat to start"} className="flex-1 border rounded-xl px-4 py-2" disabled={!session} />
          <button onClick={handleSend} className="bg-blue-600 text-white px-4 py-2 rounded-xl" disabled={!session}>Send</button>
        </div>
      </div>
    </div>
  );
}
