import React, { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import ChatWindow from "../components/ChatWindow";
import ThemeToggle from "../components/ThemeToggle";

export default function ChatPage() {
  const { sessionId } = useParams();
  const navigate = useNavigate();

  const [sessions, setSessions] = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [collapsed, setCollapsed] = useState(false);
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  const loadSessions = useCallback(async () => {
    const res = await fetch("http://localhost:5000/api/sessions");
    const data = await res.json();
    setSessions(data);
  }, []);

  const loadSession = useCallback(async (id) => {
    if (!id || id === "new") {
      setActiveSession(null);
      return;
    }
    const res = await fetch(`http://localhost:5000/api/sessions/${id}`);
    if (res.ok) {
      const s = await res.json();
      setActiveSession(s);
    } else {
      setActiveSession(null);
    }
  }, []);

  useEffect(() => {
    Promise.resolve().then(() => {
      loadSessions();
      loadSession(sessionId);
    });
  }, [sessionId, loadSessions, loadSession]);

  const createNewSession = async (initialTitle) => {
    const res = await fetch("http://localhost:5000/api/sessions/new", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: initialTitle || "" })
    });
    const data = await res.json();
    await loadSessions();
    navigate(`/chat/${data.sessionId}`);
  };

  const refreshActive = async () => {
    if (!activeSession?.id) return;
    const res = await fetch(`http://localhost:5000/api/sessions/${activeSession.id}`);
    if (res.ok) {
      const s = await res.json();
      setActiveSession(s);
      await loadSessions();
    }
  };

  const renameSession = async (id, title) => {
    await fetch(`http://localhost:5000/api/sessions/${id}/rename`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title })
    });
    await loadSessions();
    if (activeSession?.id === id) await loadSession(id);
  };

  const deleteSession = async (id) => {
    await fetch(`http://localhost:5000/api/sessions/${id}`, { method: "DELETE" });
    await loadSessions();
    if (activeSession?.id === id) navigate("/");
  };

  return (
    <div className={`h-screen ${theme === "dark" ? "dark" : ""}`}>
      <div className="flex h-full">
        <div className={`${collapsed ? "w-16" : "w-72"} transition-all bg-white border-r`}>
          <Sidebar
            collapsed={collapsed}
            setCollapsed={setCollapsed}
            sessions={sessions}
            activeSessionId={activeSession?.id}
            createNewSession={createNewSession}
            onSelect={(id) => navigate(`/chat/${id}`)}
            renameSession={renameSession}
            deleteSession={deleteSession}
          />
        </div>
        <div className="flex-1 flex flex-col">
          <div className={`p-3 border-b flex items-center justify-between ${theme === "dark" ? "bg-gray-800 text-white" : "bg-white"}`}>
            <div className="font-semibold">Session Chat</div>
            <div className="flex items-center gap-3">
              <ThemeToggle theme={theme} setTheme={setTheme} />
            </div>
          </div>
          <div className="flex-1">
            <ChatWindow
              session={activeSession}
              refresh={refreshActive}
              createNewSession={() => createNewSession()}
              theme={theme}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
