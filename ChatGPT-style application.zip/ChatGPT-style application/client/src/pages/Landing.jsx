import React from "react";
import { useNavigate } from "react-router-dom";

export default function Landing() {
  const navigate = useNavigate();
  return (
    <div className="h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-xl p-6 bg-white rounded shadow">
        <div className="text-red-500 text-3xl font-bold mb-4">TAILWIND IS WORKING 🎉</div>
        <h1 className="text-2xl font-semibold mb-4">Welcome to Session Chat</h1>
        <p className="text-sm text-gray-600 mb-6">Start a new chat session or open an existing session from the sidebar after creation.</p>
        <div className="flex gap-3">
          <button onClick={() => navigate("/chat/new")} className="bg-green-600 text-white px-4 py-2 rounded">New Chat</button>
          <button onClick={() => navigate("/chat")} className="bg-gray-200 px-4 py-2 rounded">Open Chat UI</button>
        </div>
      </div>
    </div>
  );
}
